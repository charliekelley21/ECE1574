#include <iostream>
#include <cmath>
#include <string>

using std::string;
using std::cin;
using std::cout;
using std::endl;
 
void quadradic();


 #ifndef RECIPE_H
 #define RECIPE_H
 
 #include "Ingredient.h"
 
 class Recipe
 {
 private:
     int size;
     int count;
     Ingredient *list;
 
     string steps; 
     string name; 
 
     void grow();
 
     void cover_up( int location);
 
     void make_hole( int location );
 public:
 
     Recipe();
 
     bool add_ingredient( Ingredient i, int location );
 
     Ingredient remove_ingredient( int location );
 
     void show_recipe( std::ostream &out ) const;
 
     void update_steps( string new_steps );
 
     string get_steps() const;
 
     Ingredient get_ingredient( int location ) const;
 
     int get_ingredient_count() const;
 
     string get_name() const;
 
     void update_name( string new_name );
     
 };
 
 #endif
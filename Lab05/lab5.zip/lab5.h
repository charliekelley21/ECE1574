#include <iostream>
#include <string>
#include <cmath>
#include <iomanip>

using namespace std;

using std::cin;
using std::cout;
using std::endl;
using std::string;

void mathCalculator();